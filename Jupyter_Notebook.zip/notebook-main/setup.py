# setup.py shim for use with versions of JupyterLab that require
# it for extensions.
__import__("setuptools").setup()
