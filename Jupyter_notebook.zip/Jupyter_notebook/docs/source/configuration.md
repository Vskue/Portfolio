# Configuration

```{toctree}
:caption: Configuration
:maxdepth: 1

configuring/config_overview
Security <https://jupyter-server.readthedocs.io/en/stable/operators/security.html>
extending/index.rst
```
